select First_Name,Last_Name
from student
where First_Name Like 'o%';

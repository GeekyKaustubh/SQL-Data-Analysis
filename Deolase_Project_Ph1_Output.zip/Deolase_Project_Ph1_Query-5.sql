select First_Name,Last_Name,zip,MAJOR
from student
where ZIP='32826' or zip ='33186';
select First_Name,Last_Name,zip,MAJOR
from student
where ZIP='97912' and Major='CS';

select First_Name,Last_Name
from student
where MAJOR in ('Business','Mathematics');

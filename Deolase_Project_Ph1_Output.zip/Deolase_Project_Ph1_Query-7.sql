select First_Name,Last_Name
from student
where class between 2 and 4
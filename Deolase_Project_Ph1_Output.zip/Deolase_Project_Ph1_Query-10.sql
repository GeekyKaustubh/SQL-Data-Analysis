select Status, count(*) as CountStatus
from student
group by Status
Order By CountStatus;
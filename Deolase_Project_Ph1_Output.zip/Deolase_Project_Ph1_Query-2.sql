select distinct Major
From student;

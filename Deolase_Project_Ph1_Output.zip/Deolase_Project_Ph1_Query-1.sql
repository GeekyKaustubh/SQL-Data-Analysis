select First_Name,Last_Name 
from student;

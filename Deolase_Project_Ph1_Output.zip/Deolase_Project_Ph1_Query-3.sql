select First_Name,Last_Name,zip 
from student
where ZIP= '32828';
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS CLASS;
SET FOREIGN_KEY_CHECKS=1;
CREATE TABLE CLASS
(Class_Id Varchar(10) Not Null,
Room_No Varchar(10),
Course_No Varchar(10),
Section_No Varchar(10),
Semester_Name Varchar(15),
Year int(4),
Instructor_Id Varchar(20),
Campus_Name Varchar(20),
Start_Date Varchar(20),
Start_Time Varchar(20),
Unique Key(Class_Id),
Primary Key(Class_Id));
INSERT INTO CLASS(Class_ID,Room_No,Course_No,Section_No,Semester_Name,Year,Instructor_ID,Campus_Name,Start_Date,Start_Time)
	VALUES('1001','RN0001','M1','SN100','FALL','2024','A111','SFO','2024-02-08','8:00');
INSERT INTO CLASS(Class_ID,Room_No,Course_No,Section_No,Semester_Name,Year,Instructor_ID,Campus_Name,Start_Date,Start_Time)
	VALUES('1002','RN0002','M2','SN101','FALL','2024','B222','CHICO','2024-02-08','8:00');
INSERT INTO CLASS(Class_ID,Room_No,Course_No,Section_No,Semester_Name,Year,Instructor_ID,Campus_Name,Start_Date,Start_Time)
	VALUES('1003','RN0003','M3','SN102','SPRING','2024','C333','FRESNO','2024-02-08','8:00');
INSERT INTO CLASS(Class_ID,Room_No,Course_No,Section_No,Semester_Name,Year,Instructor_ID,Campus_Name,Start_Date,Start_Time)
	VALUES('1004','RN0004','M4','SN103','SUMMER','2024','D444','LA','2024-02-08','8:00');
commit;
show tables;
Select * from CLASS;
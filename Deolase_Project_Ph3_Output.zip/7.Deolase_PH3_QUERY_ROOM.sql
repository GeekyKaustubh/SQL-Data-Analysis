SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS ROOM;
SET FOREIGN_KEY_CHECKS=1;
CREATE TABLE ROOM
(
Room_No    Varchar(200) NOT NULL,
Campus_Name VARCHAR(20),
Facility Varchar(200),
Capacity Int(2),

PRIMARY KEY(Room_No)
);
INSERT INTO ROOM(Room_No,Campus_Name,Facility,Capacity)
	VALUES('RN0001','SFO','Free Wi-fi,Job fair,Low Intrest Student Loan & Grants, Laptop, Library Accesses, Subsidised Meal,In-Campus Job','50');
INSERT INTO ROOM(Room_No,Campus_Name,Facility,Capacity)
	VALUES('RN0002','CHICO','Free Wi-fi,Low Intrest Student Loan & Grants, Library Accesses, Subsidised Meal,In-Campus Job','50');
INSERT INTO ROOM(Room_No,Campus_Name,Facility,Capacity)
	VALUES('RN0003','FRESNO','Free Wi-fi,Job fair,Low Intrest Student Loan & Grants, Laptop, Library Accesses, ,In-Campus Job','50');
INSERT INTO ROOM(Room_No,Campus_Name,Facility,Capacity)
	VALUES('RN0004','LA','Free Wi-fi,Job fair,Low Intrest Student Loan & Grants, Laptop, Library Accesses, Subsidised Meal','50');
Commit;
SHOW TABLES;
Select * from ROOM
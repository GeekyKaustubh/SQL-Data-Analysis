SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS CAMPUS;
SET FOREIGN_KEY_CHECKS=1;
CREATE TABLE CAMPUS
(
#SerialNo MEDIUMINT NOT NULL AUTO_INCREMENT,
Campus_Name Varchar(10) Not Null,
Address Varchar(200) NOT NULL,
Zip VARCHAR(20),
Phone_Number Varchar(200),
PRIMARY KEY(Campus_Name)
);
INSERT INTO CAMPUS(Campus_Name,Address,Zip,Phone_Number)
	VALUES('SFO','1600 Holloway Avenue San Francisco','94132','+1 415-338-2234');
INSERT INTO CAMPUS(Campus_Name,Address,Zip,Phone_Number)
	VALUES('CHICO','400 West First Street Chico','95929-0722','+1 530-898-6322');
INSERT INTO CAMPUS(Campus_Name,Address,Zip,Phone_Number)
	VALUES('FRESNO','5241 N. Maple Avenue Fresno','93740','+1 559-278-2261');
INSERT INTO CAMPUS(Campus_Name,Address,Zip,Phone_Number)
	VALUES('LA','5151 State University Drive Los Angeles','90032','+1 323-343-3901');
Commit;
SHOW TABLES;
Select * from CAMPUS
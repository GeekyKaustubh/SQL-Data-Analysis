SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS STUDENT_GRADE;
SET FOREIGN_KEY_CHECKS=1;
CREATE TABLE STUDENT_GRADE
(
Student_ID    MEDIUMINT NOT NULL AUTO_INCREMENT,
Class_ID      Varchar(10),
Student_Grade ENUM('A','B','C','D',"E",'F','I','W'),
PRIMARY KEY(Student_ID)
);
INSERT INTO STUDENT_GRADE (Student_ID,Class_ID, Student_Grade) 
	VALUES('1','1001','F'); 
INSERT INTO STUDENT_GRADE (Student_ID,Class_ID, Student_Grade) 
	VALUES('2','1002','B');
INSERT INTO STUDENT_GRADE (Student_ID,Class_ID, Student_Grade) 
	VALUES('3','1003','F'); 
Commit;
SHOW TABLES;
select * from student_grade;